<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./styles/stylesIndex.css">
    <title>Index</title>
</head>
<body>
    <main>
        <h1>Menú de la Tarea</h1>
        <nav>
            <ul>
                <li><a href="./academy.php">Academia</a></li>
                <li><a href="./biblioteca.php">Biblioteca</a></li>
                <li><a href="./triangle.php">Triángulo</a></li>
            </ul>
        </nav>
    </main>
</body>
</html>